#include "ChHashTable.h"
#include "cmath"

// ObjectAllocator: the usual.
// Config: the configuration for the hash table.
template <typename T>
ChHashTable<T>::ChHashTable(const HTConfig& Config, ObjectAllocator* allocator){
    //Initialize the list for the head nodes
    // m_head_Node = new ChHTHeadNode[Config.InitialTableSize_];

    m_stats.Allocator_ = allocator;
    m_stats.HashFunc_ = Config.HashFunc_;
    m_stats.TableSize_ = Config.InitialTableSize_;
}

template <typename T>
ChHashTable<T>::~ChHashTable(){
    clear();
    // delete[] m_head_Node;
}

// Insert a key/data pair into table. Throws an exception if the
// insertion is unsuccessful.(E_DUPLICATE, E_NO_MEMORY)
template <typename T>
void ChHashTable<T>::insert(const char *Key, const T& Data){
    int key_index = m_stats.HashFunc_(Key, m_stats.TableSize_);

    while(&m_head_Node[key_index] != nullptr && m_head_Node[key_index].Nodes->Key == Key){
        key_index = m_stats.HashFunc_(Key, m_stats.TableSize_ + 1);
    }

    if(&m_head_Node[key_index] != nullptr){
        delete[] &m_head_Node[key_index];
    }


}

// Delete an item by key. Throws an exception if the key doesn't exist.
// (E_ITEM_NOT_FOUND)
template <typename T>
void ChHashTable<T>::remove(const char *Key){

}

// Find and return data by key. throws exception if key doesn't exist.
// (E_ITEM_NOT_FOUND)
template <typename T>
const T& ChHashTable<T>::find(const char *Key) const{

}

// Removes all items from the table (Doesn't deallocate table)
template <typename T>
void ChHashTable<T>::clear(){

}

// Allow the client to peer into the data. Returns a struct that contains 
// information on the status of the table for debugging and testing. 
// The struct is defined in the header file.
template <typename T>
HTStats ChHashTable<T>::GetStats() const{
    return m_stats;
}

template <typename T>
const typename ChHashTable<T>::ChHTHeadNode* ChHashTable<T>::GetTable() const{

}

template <typename T>
void ChHashTable<T>::GrowTable(){
    double factor = std::ceil(TableSize_ * Config_.GrowthFactor_); // Need to include <cmath>
    unsigned new_size = GetClosestPrime(static_cast<unsigned>(factor)); // Get new prime size

    m_stats.TableSize_ = new_size;
    

}
