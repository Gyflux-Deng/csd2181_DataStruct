g++ -o vpl_execution support.cpp ObjectAllocator.cpp driver-sample.cpp -std=c++14 -pedantic -Wall -Wextra -Wconversion -Wno-deprecated
./vpl_execution