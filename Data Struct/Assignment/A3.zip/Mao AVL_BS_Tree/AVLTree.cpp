/*!
* @file			AVLTree.cpp
* @author		Maojie Deng, 2200840, maojie.deng@digipen.edu
* @date			27/2/2024
* @par			Assignment 3 : AVL trees
* @brief		This file contains the function for AVLTree.
*/

#include "AVLTree.h"


template <typename T>
AVLTree<T>::AVLTree(ObjectAllocator *oa, bool ShareOA) : BSTree<T>(oa, ShareOA)
{
}

template <typename T>
void AVLTree<T>::insert(const T& value)
{
    insertAVL(this->get_root(), value);
}

template <typename T>
void AVLTree<T>::remove(const T& value)
{
    removeAVL(this->get_root(), value); 
}

template <typename T>
bool AVLTree<T>::ImplementedBalanceFactor(void)
{
    return false;
}


template <typename T>
void AVLTree<T>::insertAVL(BinTree& root, const T& value)
{
    BinTreeStack visitedNodes;
    InsertAVLItem(root, value, visitedNodes);
}

template <typename T>
void AVLTree<T>::InsertAVLItem(BinTree& root, const T& value, BinTreeStack& path)
{
   if(root == nullptr)
   {
      root = BSTree<T>::make_node(value);
      BalanceTree(path);
   }  
   else if( value < root->data)
   {
      path.push(&root);
      ++root->count;
      InsertAVLItem(root->left, value, path);
   }
   else if( value > root->data)
   {
      path.push(&root);
      ++root->count;
      InsertAVLItem(root->right, value, path);
   }
 
}
template <typename T>
void AVLTree<T>::removeAVL(BinTree& root, const T& value)
{
    BinTreeStack visitedNodes;
    RemoveAVLItem(root, value, visitedNodes);
}

template <typename T>
void AVLTree<T>::RemoveAVLItem(BinTree& root, const T& value, BinTreeStack& path)
{
    if(root == nullptr)
    {
        return;
    }
    else if (value < root->data)
    {
        path.push(&root);
        --root->count;
        RemoveAVLItem(root->left, value, path);
    }
    else if (value > root->data)
    {
        path.push(&root);
        --root->count;
        RemoveAVLItem(root->right, value, path);
    }
    else
    {
        --root->count;
        if(!root->left || !root->right)
        {
            BinTree temp = root;
            root = (root->left) ? root->left : root->right;
            BSTree<T>::free_node(temp);
        }
        else
        {
            BinTree temp{};
            BSTree<T>::find_predecessor(root, temp);
            root->data = temp->data;
            path.push(&root);
            //--root->count;
            RemoveAVLItem(root->left, temp->data, path);
        }
        BalanceTree(path);
    }
}

template <typename T>
void AVLTree<T>::BalanceTree(BinTreeStack& path)
{
    while (!path.empty())
    {
        BinTree* temp = path.top();
        path.pop();
        
        int leftCount = BSTree<T>::tree_height((*temp)->left);
        int rightCount = BSTree<T>::tree_height((*temp)->right);
        if ((leftCount - rightCount) > 1)
        {
            if (BSTree<T>::tree_height((*temp)->left->right) >BSTree<T>::tree_height((*temp)->left->left))
            {
                LeftRotate((*temp)->left);
            }
            RightRotate((*temp));
        }
        else if ((rightCount - leftCount) > 1)
        {
            if (BSTree<T>::tree_height((*temp)->right->left) > BSTree<T>::tree_height((*temp)->right->right))
            {
                RightRotate((*temp)->right);
            }
            LeftRotate((*temp));
        }
        UpdateCount((*temp));
    }
    
}

template <typename T>
int AVLTree<T>::NodeCount(BinTree root)
{
    if (root == nullptr)
    {
        return 0;
    }

    root->count = 1 + NodeCount(root->left) + NodeCount(root->right);
    return root->count;
}

template <typename T>
void AVLTree<T>::RightRotate(BinTree& root)
{
    BinTree temp = root;
    root = temp->left;
    temp->left = root->right;
    root->right = temp;
}

template <typename T>
void AVLTree<T>::LeftRotate(BinTree& root)
{
    BinTree temp = root;
    root = temp->right;
    temp->right = root->left;
    root->left = temp;
}

template <typename T>
void AVLTree<T>::UpdateCount(BinTree& root)
{
    if (root != nullptr)
    {
        NodeCount(root);
        UpdateCount(root->left);
        UpdateCount(root->right);
    }
}