/*!
* @file			Sudoku.cpp
* @author		Maojie Deng, 2200840, maojie.deng@digipen.edu
* @date			5/3/2024
* @par			Bonus Assignment  : Recursive Sudoku Solver
* @brief		Implementation of the Sudoku class functions to solve ur sudoku
*/

#include "Sudoku.h"
#include <iostream>



/**
 * @brief Constructs a Sudoku object.
 * 
 * @param basesize The size of the base grid.
 * @param stype The symbol type of the Sudoku.
 * @param callback The callback function for Sudoku solving.
 */
Sudoku::Sudoku(int basesize, SymbolType stype, SUDOKU_CALLBACK callback) :callback_(callback),symbolType(stype)
{

  // Initialize the stats
  stats.basesize = basesize;
  stats.placed = 0;
  stats.moves = 0;
  stats.backtracks = 0;
  // Initialize the board
  boardWidth = basesize * basesize;
  sudokuBoard = new char[boardWidth * boardWidth];
}

// Destructor
Sudoku::~Sudoku()
{
    delete[] sudokuBoard;
}

/**
 * @brief Sets up the Sudoku board with the given values.
 * 
 * This function takes an array of characters representing the initial values of the Sudoku board
 * and sets up the board accordingly. The size parameter specifies the number of elements in the
 * values array.
 * 
 * @param values An array of characters representing the initial values of the Sudoku board.
 * @param size The number of elements in the values array.
 */
void Sudoku::SetupBoard(const char *values, int size)
{
  // Set the board values
  for (size_t i = 0; i < static_cast<size_t>(size); ++i)
  {
    // If the value is a dot, set it to the empty character
    sudokuBoard[i] = values[i] == '.' ? EMPTY_CHAR : values[i];
  }
}

/**
 * @brief Solves the Sudoku puzzle.
 * 
 * This function starts solving the Sudoku puzzle by calling the callback function to start the game.
 * It then uses the place_value function to solve the puzzle.
 * Finally, it calls the callback function to finish the game, indicating whether the puzzle was solved successfully or not.
 */
void Sudoku::Solve()
{
  // Start from the first cell
  int sudokuRow = 0;
  int sudokuCol = 0;
  
  // Call the callback function to start the game
  callback_(*this, sudokuBoard, MessageType::MSG_STARTING, stats.moves, stats.basesize, -1, 0);

  // Start solving the sudoku
  bool pass = place_value(sudokuRow, sudokuCol); 

  // Call the callback function to finish the game
  pass ? callback_(*this, sudokuBoard, MessageType::MSG_FINISHED_OK, stats.moves, stats.basesize, -1, 0)
       : callback_(*this, sudokuBoard, MessageType::MSG_FINISHED_FAIL, stats.moves, stats.basesize, -1, 0);
}


/**
 * @brief Retrieves the current state of the Sudoku board.
 * 
 * This function returns a pointer to the current state of the Sudoku board.
 * The Sudoku board is represented as an array of characters.
 * 
 * @return A pointer to the current state of the Sudoku board.
 */
const char *Sudoku::GetBoard() const
{
  return sudokuBoard;
}

/**
 * @brief Retrieves the statistics of the Sudoku puzzle.
 * 
 * This function returns the statistics of the Sudoku puzzle, including the size of the base grid,
 * the number of cells placed, the number of moves made, and the number of backtracks performed.
 * 
 * @return The statistics of the Sudoku puzzle.
 */
Sudoku::SudokuStats Sudoku::GetStats() const
{
  return stats;
}

/**
 * @brief Tries to place a value in the specified cell and recursively solve the puzzle.
 * 
 * This function attempts to place a valid value in the given cell (row, col) and
 * recursively solve the Sudoku puzzle. If the current cell is already filled or
 * if placing a certain value leads to a solution, it moves to the next cell. If
 * no valid value leads to a solution, it backtracks to the previous cell and tries
 * a different value.
 * 
 * @param row The row index of the cell.
 * @param col The column index of the cell.
 * @return true If the puzzle is successfully solved.
 * @return false If no valid value can be placed in the current cell, indicating backtracking.
 */
bool Sudoku::place_value(int row, int col)
{
    // Increment the number of moves
    //++stats.moves;

    // If the row is equal to the board width, the puzzle is solved
    if (row == static_cast<int>(boardWidth))
    {
      return true;
    }

    // If the current cell is not empty, move to the next cell
    if (sudokuBoard[row * boardWidth + col] != EMPTY_CHAR)
    {
      // If the current cell is the last cell in the row, move to the next row
      if (col == (static_cast<int>(boardWidth) - 1))
      {
        return place_value(row + 1, 0);
      }
      // Otherwise, move to the next cell in the row
      else
      {
        return place_value(row, col + 1);
      }
      return false;
    }

    char value{};
    if (symbolType == SymbolType::SYM_NUMBER)
    {
      value = '1';
    }
    else if (symbolType == SymbolType::SYM_LETTER)
    {
      value = 'A';
    }
    else
    {
      value = 'a';
    }

    for (int i = 0; i <static_cast<int>(boardWidth); ++i)
    {
        ++stats.moves;
      if (isValidMove(row, col, value))
      {
        sudokuBoard[row * boardWidth + col] = value;
        ++stats.placed;
        callback_(*this, sudokuBoard, MessageType::MSG_PLACING, stats.moves, stats.basesize, row * boardWidth + col, value);
    
        if (col == (static_cast<int>(boardWidth) - 1))
        {
          if (place_value(row + 1, 0))
          {
            return true;
          }
        }
        else
        {
          if (place_value(row, col + 1))
          {
            return true;
          }
        }
        sudokuBoard[row * boardWidth + col] = EMPTY_CHAR;
        ++stats.backtracks;
        --stats.placed;
      }
      ++value;
  }


  // If no value can be placed in the current cell, backtrack
  return false;
}

/**
 * @brief Checks if placing a certain value in a specified cell is valid according to Sudoku rules.
 * 
 * This method verifies whether a given value can be placed in a specified cell without
 * violating Sudoku rules: the value must not already exist in the same row, column, or
 * sub-grid.
 * 
 * @param row The row index of the cell.
 * @param col The column index of the cell.
 * @param num The value to check for validity.
 * @return true If the value does not violate any rules and can be placed in the cell.
 * @return false If the value violates Sudoku rules for the specified cell.
 */
bool Sudoku::isValidMove(int row, int col, char num)
{
  // Check if the number is already in the row
  for (int i = 0; i < static_cast<int>(boardWidth); ++i)
  {
    if (sudokuBoard[row * boardWidth + i] == num)
    {
      return false;
    }
  }

  // Check if the number is already in the column
  for (int i = 0; i < static_cast<int>(boardWidth); ++i)
  {
    if (sudokuBoard[i * boardWidth + col] == num)
    {
      return false;
    }
  }

  // Check if the number is already in the sub-grid
  int subGridRow = row - row % stats.basesize;
  int subGridCol = col - col % stats.basesize;
  for (int i = 0; i < stats.basesize; ++i)
  {
    for (int j = 0; j < stats.basesize; ++j)
    {
      if (sudokuBoard[(i + subGridRow) * boardWidth + j + subGridCol] == num)
      {
        return false;
      }
    }
  }

  return true;
}

