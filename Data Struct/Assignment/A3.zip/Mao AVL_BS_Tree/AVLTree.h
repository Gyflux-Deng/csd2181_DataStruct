//---------------------------------------------------------------------------
#ifndef AVLTREE_H
#define AVLTREE_H
//---------------------------------------------------------------------------
#include <stack>
#include "BSTree.h"
/*!
* @file			AVLTree.hpp
* @author		Maojie Deng, 2200840, maojie.deng@digipen.edu
* @date			27/2/2024
* @par			Assignment 3 : AVL trees
* @brief		This file contains the function for AVLTree header file.
*/


/*!
  Definition for the AVL Tree
*/
template <typename T>
class AVLTree : public BSTree<T>
{
  public:
    AVLTree(ObjectAllocator *oa = 0, bool ShareOA = false);
    virtual ~AVLTree() = default; // DO NOT IMPLEMENT
    virtual void insert(const T& value) override;
    virtual void remove(const T& value) override;
    // Returns true if efficiency implemented
    static bool ImplementedBalanceFactor(void);


  private:
    // Simplified type alias || !shorthand for BinTreeNode*
    using BinTree = typename BSTree<T>::BinTree;
    using BinTreeStack = std::stack<BinTree*>;
    
    // private stuff
    void insertAVL(BinTree& root, const T& value);
    void InsertAVLItem(BinTree& root, const T& value, BinTreeStack& path);
    void removeAVL(BinTree& root, const T& value);
    void RemoveAVLItem(BinTree& root, const T& value, BinTreeStack& path);
    void BalanceTree(BinTreeStack& path);
    void RightRotate(BinTree& root);
    void LeftRotate(BinTree& root);
    int NodeCount(BinTree root);
    void UpdateCount(BinTree& root);
    void GetCount(BinTree& root);
};

#include "AVLTree.cpp"

#endif
//---------------------------------------------------------------------------
