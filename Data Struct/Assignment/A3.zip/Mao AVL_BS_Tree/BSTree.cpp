/*!
* @file			BSTree.cpp
* @author		Maojie Deng, 2200840, maojie.deng@digipen.edu
* @date			27/2/2024
* @par			Assignment 3 : BS trees
* @brief		This file contains the function for BSTree.
*/

#include "BSTree.h"
/**
 * @brief Constructor for initializing the BST with an optional custom object allocator.
 * 
 * This constructor initializes a binary search tree (BST). It allows for the optional use
 * of a custom object allocator for efficient memory management. If a custom allocator is
 * provided, it can be set to be shared among multiple BST instances, according to the
 * ShareOA flag.
 * 
 * @param oa Pointer to an existing ObjectAllocator instance for custom memory management.
 *           If nullptr is provided, a new ObjectAllocator will be created for this BST.
 * @param ShareOA Flag indicating whether the allocator should be shared across multiple
 *                BST instances. True enables sharing, false creates a dedicated allocator.
 */
template <typename T>
BSTree<T>::BSTree(ObjectAllocator *oa, bool ShareOA) : m_OA{nullptr}, m_freeAllocator{false}, m_shareAllocator{ShareOA}, root_Node{nullptr}
{
  // If a custom allocator is provided, use it for this BST instance.
  if(oa != nullptr)
  {
    m_OA = oa; 
  }
  else
  {
    //define a configuration for the ObjectAllocator, potentially customizing memory management.
    OAConfig config(true);
    // Create a new ObjectAllocator for tree nodes, using the specified config.
    m_OA = new ObjectAllocator(sizeof(BinTreeNode), config);
  }
 
}

/**
 * @brief Copy constructor.
 * 
 * Initializes a new instance of the BSTree by deep copying another BSTree. If the original tree
 * shares its allocator, this tree will use the same allocator. Otherwise, it creates and uses its own allocator.
 * 
 * @param rhs Reference to the BSTree instance to be copied.
 */
template <typename T>
BSTree<T>::BSTree(const BSTree& rhs)
{
  // if we are copying ourselves, return
  if (rhs.m_shareAllocator)
	{
    // if we are sharing the allocator, just copy the pointer
		m_OA = rhs.m_OA;
		m_freeAllocator = false;
		m_shareAllocator = true;	
	}
	// no sharing, create our own personal allocator
	else
	{
    //define a configuration for the ObjectAllocator, potentially customizing memory management.
		OAConfig config(true);	
		m_OA = new ObjectAllocator(sizeof(BinTreeNode), config);
		m_freeAllocator = true;		
		m_shareAllocator = false;	
	}
    // copy the tree
    copyTree(root_Node, rhs.root_Node);
}

/**
 * @brief Destructor.
 * 
 * Cleans up the BSTree by deleting all nodes and freeing the allocator if owned.
 */
template <typename T>
BSTree<T>::~BSTree()
{
  // clear the tree
  clear();
  // if we own the allocator, delete it
  if(m_freeAllocator)
  {
    // delete the allocator
    if(m_OA != nullptr)
    {
        delete m_OA;
    }
    // set the pointer to null
    m_OA = nullptr;
    
  }
}
/**
 * @brief Assignment operator.
 * 
 * Assigns the contents of another BSTree to this instance, replacing its current contents.
 * Handles self-assignment and properly manages memory to avoid leaks.
 * 
 * @param rhs The BSTree instance to assign from.
 * @return Reference to this instance after assignment.
 */
template <typename T>
BSTree<T>& BSTree<T>::operator=(const BSTree& rhs)
{  
  
  // check for self-assignment
  if (this == &rhs)
  {
    return *this;
  }
  // if we are sharing the allocator, just copy the pointer
  if(this != &rhs)
  {
    // clear the tree
    clear();
    // if we own the allocator, delete it
    if(m_freeAllocator)
    {
      delete m_OA;
    }
    // if we are sharing the allocator, just copy the pointer
    if(rhs.m_shareAllocator)
    {
      m_OA = rhs.m_OA;
      m_freeAllocator = false;
      m_shareAllocator = true;
    }
    else
    {
      // no sharing, create our own personal allocator
      OAConfig config(true);
      // Create a new ObjectAllocator for tree nodes, using the specified config.
      m_OA = new ObjectAllocator(sizeof(BinTreeNode), config);
      m_freeAllocator = true;
      m_shareAllocator = false;
    }
    // copy the tree
    copyTree(root_Node, rhs.root_Node);
  }
  // return the new tree
  return *this;
}

/**
 * @brief Accesses the node at the given index in the tree.
 * 
 * This function traverses the tree to find the node at the specified index based on an in-order traversal.
 * If the index is out of range, it returns nullptr.
 * 
 * @param index The zero-based index of the node to access.
 * @return A pointer to the node at the specified index, or nullptr if the index is out of range.
 */
template <typename T>
const typename BSTree<T>::BinTreeNode* BSTree<T>::operator[](int index) const
{
  // if the index is out of range, return null
  BinTreeNode* temp = root_Node;
  if(index < 0 || index >= nodeCount(root_Node))
  {
    return nullptr;
  }
  // return the node at the index
  return nodeAt(temp, index);
}

/**
 * @brief Inserts a new value into the binary search tree.
 * 
 * This function inserts a new node with the specified value into the binary search tree,
 * maintaining the BST properties.
 * 
 * @param value The value to insert into the tree.
 */
template <typename T>
void BSTree<T>::insert(const T& value)
{
  // insert the value into the tree
  insertNode(root_Node, value);
}

/**
 * @brief Removes a value from the binary search tree.
 * 
 * This function removes the node containing the specified value from the binary search tree,
 * if it exists, and restructures the tree to maintain the BST properties.
 * 
 * @param value The value to remove from the tree.
 */
template <typename T>
void BSTree<T>::remove(const T& value)
{
  // remove the value from the tree
  deleteNode(root_Node, value);
}

/**
 * @brief Clears the binary search tree.
 * 
 * Removes all nodes from the tree, resulting in an empty tree.
 */
template <typename T>
void BSTree<T>::clear()
{
  // clear the tree
  while(root_Node != nullptr)
  {
    deleteNode(root_Node, root_Node->data);
  }
}

/**
 * @brief Searches for a value in the binary search tree.
 * 
 * This function searches the tree for a node containing the specified value and
 * tracks the number of comparisons made during the search.
 * 
 * @param value The value to search for.
 * @param compares A reference to an unsigned variable where the number of comparisons will be stored.
 * @return True if the value is found, otherwise false.
 */
template <typename T>
bool BSTree<T>::find(const T& value, unsigned& compares) const
{
  // find the value in the tree
  BinTree temp = root_Node;
  // return the result of the search
  return findNode(temp, value, compares);
}

/**
 * @brief Helper function to recursively search for a value in the tree.
 * 
 * Increments the comparison counter and searches the tree for the specified value.
 * 
 * @param tree The subtree to search.
 * @param value The value to search for.
 * @param compares A reference to an unsigned variable to count comparisons.
 * @return True if the value is found in the subtree, otherwise false.
 */
template <typename T>
bool BSTree<T>::findNode(BinTree tree, const T& value, unsigned& compares) const
{
  // increment the comparison counter
  ++compares;
  // if the tree is empty, return false
  if(tree == nullptr)
  {
    return false;
  }
  // if the value is found, return true
  if(tree->data == value)
  {
    return true;
  }
  // if the value is less than the current node, search the left subtree
  else if(tree->data > value)
  {
    // return the result of the search
    return findNode(tree->left, value, compares);
  }
  else
  {
    // return the result of the search
    return findNode(tree->right, value, compares);
  }
}

/**
 * @brief Checks if the tree is empty.
 * 
 * @return True if the tree is empty, otherwise false.
 */
template <typename T>
bool BSTree<T>::empty() const
{
  // return true if the tree is empty
  return size() ? false : true;
}

/**
 * @brief Returns the number of nodes in the tree.
 * 
 * @return The number of nodes in the tree.
 */
template <typename T>
unsigned int BSTree<T>::size() const
{
  // return the number of nodes in the tree
  return nodeCount(root_Node);
}

/**
 * @brief Calculates the height of the tree.
 * 
 * The height is the longest path from the root to a leaf.
 * 
 * @return The height of the tree.
 */
template <typename T>
int BSTree<T>::height() const
{
  // return the height of the tree
  return tree_height(root_Node);
}

/**
 * @brief Gets the root node of the tree.
 * 
 * @return A pointer to the root node of the tree.
 */
template <typename T>
typename BSTree<T>::BinTree BSTree<T>::root() const
{
  // return the root node
  return root_Node;
}

/**
 * @brief Provides access to the root node of the tree.
 * 
 * @return A reference to the pointer of the root node.
 */
template <typename T>
typename BSTree<T>::BinTree& BSTree<T>::get_root()
{
  // return the root node
  return root_Node;
}

/**
 * @brief Allocates and constructs a new tree node with the given value.
 * 
 * @param value The value to store in the new node.
 * @return A pointer to the newly created node.
 */
template <typename T>
typename BSTree<T>::BinTree BSTree<T>::make_node(const T& value) const
{
  // allocate a new node
   try
    {
        BinTree type = reinterpret_cast<BinTree>(m_OA->Allocate());
        BinTree node = new (type) BinTreeNode(value);
        return node;
    }
    // catch any exceptions
    catch (const OAException &e)
    {
        throw(BSTException(BSTException::E_NO_MEMORY, e.what()));
    }
}

/**
 * @brief Frees a node, returning it to the allocator.
 * 
 * @param node The node to free.
 */
template <typename T>
void BSTree<T>::free_node(BinTree node)
{
  // free the node
   m_OA->Free(node);
}

/**
 * @brief Helper function to calculate the height of a subtree.
 * 
 * @param tree The subtree for which to calculate the height.
 * @return The height of the subtree.
 */
template <typename T>
int BSTree<T>::tree_height(BinTree tree) const
{
  // return the height of the tree
  if(!tree)
  {
    return -1;
  }
  // get the height of the left and right subtrees
  int leftHeight = tree_height(tree->left);
  int rightHeight = tree_height(tree->right);
  return (leftHeight > rightHeight) ? leftHeight + 1 : rightHeight + 1;
}

/**
 * @brief Finds the in-order predecessor of a given node.
 * The predecessor is the rightmost node of the left subtree.
 * @param tree The node for which to find the predecessor.
 * @param predecessor Reference to the pointer where the predecessor will be stored.
 */
template <typename T>
void BSTree<T>::find_predecessor(BinTree tree, BinTree& predecessor) const
{
  // find the predecessor of the current node
    predecessor = tree->left;
    while(predecessor->right)
    {
        predecessor = predecessor->right;
    }
}

/**
 * @brief Helper function to delete a node with the specified value from the tree.
 * Handles cases where the node to be deleted has no children, one child, or two children.
 * @param tree The subtree from which to delete the node.
 * @param data The value of the node to delete.
 */
template <typename T>
void BSTree<T>::deleteNode(BinTree& tree, const T& data)
{
  // delete the node with the specified value
   if (!tree)
      {
          return;
      }
      // if the value is found, delete the node
      else if (data < tree->data)
      {
          --tree->count;
          deleteNode(tree->left, data);
      }

      else if (data > tree->data)
      {
          --tree->count;
          deleteNode(tree->right, data);
      }
      // if the node has two children, find the predecessor and delete it
      else
      {
          --tree->count;
          if (!tree->left)
          {
              BinTree temp = tree;
              tree = tree->right;
              free_node(temp);
          }
          else if (!tree->right)
          {
              BinTree temp = tree;
              tree = tree->left;
              free_node(temp);
          }
          else
          {
              BinTree pred = nullptr;
              find_predecessor(tree, pred);
              tree->data = pred->data;
              deleteNode(tree->left, tree->data);
          }
      }
}

/**
 * @brief Helper function to recursively insert a new node with the specified value into the tree.
 * 
 * @param tree The subtree into which the new node should be inserted.
 * @param data The value to insert into the tree.
 */
template<typename T>
void BSTree<T>::insertNode(BinTree& tree, const T& data)
{
  // insert the node with the specified value
    if(tree == nullptr)
    {
        tree = make_node(data);
    }
    // if the value is less than the current node, insert it into the left subtree
    else if(data < tree->data)
    {
        ++tree->count;
        insertNode(tree->left, data);
    }
    // if the value is greater than the current node, insert it into the right subtree
    else if(data > tree->data)
    {
       ++tree->count;
        insertNode(tree->right, data);
    }

}

/**
 * @brief Helper function to recursively insert a new node with the specified value into the tree.
 * @param tree The subtree into which the new node should be inserted.
 * @param data The value to insert into the tree.
 */
template <typename T>
typename BSTree<T>::BinTree BSTree<T>::copyTree(BinTree& lhs, const BinTree& rhs)
{
  // copy the tree
    if(!rhs)
    {
        return nullptr;
    }
   // copy the current node
    lhs = make_node(rhs->data);
    lhs->count = rhs->count;
    lhs->balance_factor = rhs->balance_factor;
    lhs->left = copyTree(lhs->left, rhs->left);
    lhs->right = copyTree(lhs->right, rhs->right);
    return lhs;
}

/**
 * @brief Recursively deletes all nodes in a subtree, effectively clearing it.
 * 
 * @param tree The subtree to clear.
 */
template <typename T>
int BSTree<T>::nodeCount(BinTree tree) const
{
  // return the number of nodes in the tree
    if (!tree)
    {
      return 0;
    }        
    // return the number of nodes in the left and right subtrees 
    return 1 + nodeCount(tree->left) + nodeCount(tree->right);
}

/**
 * @brief Finds and returns the node at the specified index based on in-order traversal.
 * 
 * This function performs an in-order traversal of the tree to locate the node at the given index. 
 * The index is zero-based, meaning index 0 corresponds to the first node in the in-order sequence.
 * If the index is out of range (less than 0 or greater than the number of nodes in the tree), 
 * the function returns nullptr. This method efficiently traverses the tree by using the number of nodes 
 * in the left subtree to determine whether to search left, right, or return the current node.
 * 
 * @param tree The subtree to search for the node. Initially, this should be the root of the tree.
 * @param index The zero-based index of the node to find in the tree's in-order traversal.
 * @return A pointer to the node at the specified index if found; otherwise, nullptr.
 */
template <typename T>
typename BSTree<T>::BinTree BSTree<T>::nodeAt(BinTree tree, int index) const
{
  // return the node at the specified index
    if(tree == nullptr)
    {
        return nullptr;
    }
    // get the number of nodes in the left subtree
    int leftCount = nodeCount(tree->left);
    if(index < leftCount)
    {
        return nodeAt(tree->left, index);
    }
    else if(index > leftCount)
    {
        return nodeAt(tree->right, index - (leftCount + 1));
    }
    else
    {
        return tree;
    }    
}